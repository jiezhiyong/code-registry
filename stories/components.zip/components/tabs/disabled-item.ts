import App from "./disabled-item.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
