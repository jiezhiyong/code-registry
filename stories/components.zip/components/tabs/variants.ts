import App from "./variants.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
