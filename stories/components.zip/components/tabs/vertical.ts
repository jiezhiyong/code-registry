import App from "./vertical.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
