import App from "./controlled.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
