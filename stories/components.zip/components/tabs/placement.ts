import App from "./placement.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
