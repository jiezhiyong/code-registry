import App from "./compact.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
