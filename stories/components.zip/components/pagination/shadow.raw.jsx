import {Pagination} from "@heroui/react";

export default function App() {
  return <Pagination showShadow color="warning" initialPage={1} total={10} />;
}
