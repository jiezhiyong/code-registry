import {Pagination} from "@heroui/react";

export default function App() {
  return <Pagination loop showControls color="success" initialPage={1} total={5} />;
}
