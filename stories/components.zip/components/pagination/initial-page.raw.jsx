import {Pagination} from "@heroui/react";

export default function App() {
  return <Pagination color="warning" initialPage={3} total={10} />;
}
