import {Pagination} from "@heroui/react";

export default function App() {
  return <Pagination initialPage={1} total={10} />;
}
