import App from "./custom-impl.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
