import {Pagination} from "@heroui/react";

export default function App() {
  return <Pagination isCompact showControls initialPage={1} total={10} />;
}
