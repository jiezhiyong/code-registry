import {Pagination} from "@heroui/react";

export default function App() {
  return <Pagination isDisabled initialPage={1} total={10} />;
}
