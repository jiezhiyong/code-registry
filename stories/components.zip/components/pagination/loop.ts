import App from "./loop.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
