import App from "./max-date-value.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
