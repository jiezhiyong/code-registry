import App from "./with-month-and-year-picker.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
