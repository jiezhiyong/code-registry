import App from "./unavailable-dates.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
