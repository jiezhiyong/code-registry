import App from "./international-calendars.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
