import {Calendar} from "@heroui/react";

export default function App() {
  return <Calendar aria-label="Date (firstDayOfWeek)" firstDayOfWeek="mon" />;
}
