import {Calendar} from "@heroui/react";

export default function App() {
  return <Calendar isDisabled aria-label="Date (Disabled)" />;
}
