import {Calendar} from "@heroui/react";

export default function App() {
  return <Calendar showMonthAndYearPickers aria-label="Date (Show Month and Year Picker)" />;
}
