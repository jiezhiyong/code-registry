import App from "./arrow.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
