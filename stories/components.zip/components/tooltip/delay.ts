import App from "./delay.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
