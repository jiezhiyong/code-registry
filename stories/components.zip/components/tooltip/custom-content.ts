import App from "./custom-content.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
