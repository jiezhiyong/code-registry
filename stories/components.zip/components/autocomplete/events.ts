import App from "./events.raw.jsx?raw";
import AppTs from "./events.raw.tsx?raw";

const react = {
  "/App.jsx": App,
  "/App.tsx": AppTs,
};

export default {
  ...react,
};
