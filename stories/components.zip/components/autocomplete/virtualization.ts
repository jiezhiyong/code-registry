import App from "./virtualization.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
