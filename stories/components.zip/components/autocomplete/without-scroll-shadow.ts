import App from "./without-scroll-shadow.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
