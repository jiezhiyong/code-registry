import App from "./virtualization-max-listbox-height.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
