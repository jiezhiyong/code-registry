import App from "./custom-items.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
