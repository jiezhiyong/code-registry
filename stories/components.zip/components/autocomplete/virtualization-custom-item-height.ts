import App from "./virtualization-custom-item-height.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
