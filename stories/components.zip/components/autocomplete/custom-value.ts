import App from "./custom-value.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
