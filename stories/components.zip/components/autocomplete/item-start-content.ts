import App from "./item-start-content.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
