import App from "./disabled-items.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
