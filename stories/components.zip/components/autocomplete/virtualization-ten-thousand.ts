import App from "./virtualization-ten-thousand.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
