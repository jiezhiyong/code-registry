import App from "./custom-selector-icon.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
