import App from "./custom-empty-content-message.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
