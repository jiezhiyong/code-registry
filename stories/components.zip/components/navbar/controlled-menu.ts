import App from "./controlled-menu.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
