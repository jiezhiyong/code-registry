import App from "./with-menu.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
