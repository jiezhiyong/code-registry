import App from "./hide-on-scroll.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
