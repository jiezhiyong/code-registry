import App from "./with-avatar.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
