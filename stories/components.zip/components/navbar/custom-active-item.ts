import App from "./custom-active-item.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
