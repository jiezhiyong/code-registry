import {CircularProgress} from "@heroui/react";

export default function App() {
  return <CircularProgress aria-label="Loading..." />;
}
