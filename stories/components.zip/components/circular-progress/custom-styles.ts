import App from "./custom-styles.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
