import App from "./label.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
