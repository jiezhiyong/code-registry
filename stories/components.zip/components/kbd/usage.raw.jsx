import {Kbd} from "@heroui/react";

export default function App() {
  return <Kbd keys={["command"]}>K</Kbd>;
}
