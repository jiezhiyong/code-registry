import usage from "./usage";
import keys from "./keys";

export const kbdContent = {
  usage,
  keys,
};
