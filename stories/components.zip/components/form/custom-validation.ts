import App from "./custom-validation.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
