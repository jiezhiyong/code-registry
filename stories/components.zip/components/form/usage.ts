import App from "./form-usage.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
