import App from "./custom-error-messages.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
