import App from "./events.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
