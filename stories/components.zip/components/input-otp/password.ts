import App from "./password.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
