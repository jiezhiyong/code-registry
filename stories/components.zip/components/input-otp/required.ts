import App from "./input-otp-required.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
