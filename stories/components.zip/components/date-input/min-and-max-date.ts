import App from "./min-and-max-date.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
