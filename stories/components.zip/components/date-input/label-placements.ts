import App from "./label-placements.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
