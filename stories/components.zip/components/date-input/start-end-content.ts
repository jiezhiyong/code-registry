import App from "./start-end-content.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
