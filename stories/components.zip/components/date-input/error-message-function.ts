import App from "./error-message-function.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
