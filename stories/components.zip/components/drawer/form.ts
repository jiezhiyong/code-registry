import App from "./form.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
