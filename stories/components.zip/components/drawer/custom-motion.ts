import App from "./custom-motion.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
