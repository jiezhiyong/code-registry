import App from "./page-behavior.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
