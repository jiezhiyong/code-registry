import {DateRangePicker} from "@heroui/react";

export default function App() {
  return <DateRangePicker className="max-w-xs" label="Stay duration" />;
}
