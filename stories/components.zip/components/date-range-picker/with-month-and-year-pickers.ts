import App from "./with-month-and-year-pickers.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
