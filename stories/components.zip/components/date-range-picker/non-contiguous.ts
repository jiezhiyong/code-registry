import App from "./non-contiguous.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
