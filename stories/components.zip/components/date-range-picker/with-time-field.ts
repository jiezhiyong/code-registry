import App from "./with-time-field.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
