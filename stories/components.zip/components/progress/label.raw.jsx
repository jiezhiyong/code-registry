import {Progress} from "@heroui/react";

export default function App() {
  return <Progress className="max-w-md" label="Loading..." value={55} />;
}
