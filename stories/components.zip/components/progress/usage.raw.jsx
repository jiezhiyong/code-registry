import {Progress} from "@heroui/react";

export default function App() {
  return <Progress aria-label="Loading..." className="max-w-md" value={60} />;
}
