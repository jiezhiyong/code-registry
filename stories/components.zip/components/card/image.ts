import App from "./image.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
