import App from "./action.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
