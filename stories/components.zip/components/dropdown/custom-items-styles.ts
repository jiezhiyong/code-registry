import App from "./custom-items-styles.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
