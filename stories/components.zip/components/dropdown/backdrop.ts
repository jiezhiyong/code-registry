import App from "./backdrop.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
