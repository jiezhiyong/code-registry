import App from "./custom-size.raw.jsx?raw";

const react = {
  "/App.jsx": App,
};

export default {
  ...react,
};
